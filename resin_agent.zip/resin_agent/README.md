# 🧪 Resin & Adhesive Intelligence Agent

گزارش روزانه هوشمند رزین، چسب، و PSA — ارسال خودکار به تلگرام

---

## ✅ راه‌اندازی در ۵ مرحله

### مرحله ۱ — ساخت ربات تلگرام

1. در تلگرام به `@BotFather` پیام بده
2. دستور `/newbot` بزن
3. یک نام بده → **Bot Token** دریافت می‌کنی (شبیه: `123456789:AAF...`)
4. Chat ID خودت را از `@userinfobot` بگیر

---

### مرحله ۲ — دریافت Anthropic API Key

1. به [console.anthropic.com](https://console.anthropic.com) برو
2. یک API Key جدید بساز (شروع با `sk-ant-...`)
3. این key را کپی کن

---

### مرحله ۳ — ایجاد Repository در GitHub

1. به [github.com](https://github.com) برو → New Repository
2. نام: `resin-intelligence-agent` (Private یا Public)
3. فایل‌های این پروژه را آپلود کن:
   - `main.py`
   - `requirements.txt`
   - `.github/workflows/daily_report.yml`
   - `.gitignore`
   - `README.md`

---

### مرحله ۴ — تنظیم Secrets در GitHub

در Repository → Settings → Secrets and variables → Actions → New repository secret:

| نام Secret | مقدار |
|---|---|
| `ANTHROPIC_API_KEY` | `sk-ant-...` |
| `TELEGRAM_BOT_TOKEN` | `123456789:AAF...` |
| `TELEGRAM_CHAT_ID` | `-1001234567890` یا `@username` |

---

### مرحله ۵ — تست اجرا

در GitHub: Actions → "Resin & Adhesive Daily Intelligence Report" → Run workflow

گزارش ظرف ۳-۵ دقیقه به تلگرامت می‌رسد ✅

---

## 🕗 زمان‌بندی خودکار

ایجنت هر روز ساعت **۰۸:۰۰ صبح به وقت تهران** اجرا می‌شود.

برای تغییر ساعت، در فایل `daily_report.yml` مقدار `cron` را ویرایش کن:
- ساعت ۰۸:۰۰ تهران = `30 4 * * *` (UTC)
- ساعت ۰۷:۰۰ تهران = `30 3 * * *` (UTC)
- ساعت ۰۹:۰۰ تهران = `30 5 * * *` (UTC)

---

## 💻 اجرای محلی (روی لپ‌تاپ)

```bash
# ۱. نصب وابستگی‌ها
pip install -r requirements.txt

# ۲. ساخت فایل .env
cp .env.example .env
# سپس فایل .env را ویرایش کن و کلیدها را وارد کن

# ۳. اجرا
python main.py
```

---

## 📦 ساختار فایل‌ها

```
resin-intelligence-agent/
├── main.py                          ← کد اصلی ایجنت
├── requirements.txt                 ← وابستگی‌های Python
├── .env.example                     ← نمونه فایل کانفیگ محلی
├── .gitignore                       ← فایل .env را push نکن!
├── README.md                        ← این راهنما
└── .github/
    └── workflows/
        └── daily_report.yml         ← زمان‌بندی GitHub Actions
```

---

## 🔧 شخصی‌سازی

برای تغییر موضوعات جستجو، در `main.py` بخش `USER_PROMPT` را ویرایش کن.

برای افزودن منابع جدید، query های جستجو را گسترش بده.

---

## ❓ مشکلات رایج

| مشکل | راه‌حل |
|---|---|
| `Telegram error: Unauthorized` | Bot Token اشتباه است |
| `Telegram error: chat not found` | Chat ID اشتباه است — ابتدا به ربات پیام بده |
| `anthropic.AuthenticationError` | API Key اشتباه یا منقضی شده |
| گزارش خالی | اینترنت یا web_search در دسترس نیست |
