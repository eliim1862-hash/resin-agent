"""
Resin & Adhesive Intelligence Agent
====================================
هر روز ساعت ۰۸:۰۰ اخبار ۲۴ ساعته رزین و چسب را جمع‌آوری،
تحلیل، و به تلگرام ارسال می‌کند.

وابستگی‌ها:  pip install anthropic requests python-dotenv
"""

import os
import json
import requests
from datetime import datetime, timezone
from dotenv import load_dotenv
import anthropic

load_dotenv()

BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
CHAT_ID   = os.environ["TELEGRAM_CHAT_ID"]
ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]

# ───────────────────────────────────────────────
# ۱. ساخت پرامپت جستجو
# ───────────────────────────────────────────────

SYSTEM_PROMPT = """
You are a senior R&D director and technology scout specializing in:
Pressure Sensitive Adhesives (PSA), Acrylic Emulsions, Vinyl Acrylic Resins,
Styrene Acrylic Resins, Water-Based Adhesives, Hot Melt Adhesives,
Reactive Adhesives, Coatings, Sealants, Polymer Emulsions,
Sustainable/Bio-Based Adhesives, Specialty Monomers, Crosslinkers.

Your mission: Search the web for the LAST 24 HOURS only and generate a
professional executive intelligence report in Persian (Farsi).

Prioritize:
- New products and formulations
- New patents (Google Patents, WIPO, USPTO, EPO)
- Scientific papers (ScienceDirect, ACS, Springer, MDPI)
- Industry news (ASI Magazine, PCI, Coatings World, SpecialChem, ICIS, BASF/Dow/Henkel/Arkema/Synthomer press releases)
- Market news: acquisitions, partnerships, investments
- Regional focus: Iran + Middle East + Global

RULES:
- Only last 24 hours
- Remove duplicates
- Always include source URL
- Ignore low-quality blogs
- Write the full report IN PERSIAN (Farsi)
- Report length: 2500-4000 words
- Use Markdown formatting with emojis for section headers

REPORT STRUCTURE (in Persian):

🧪 گزارش هوشمند رزین و چسب | {date}

📌 خلاصه اجرایی
(5-8 مورد مهم‌ترین رویدادها)

🆕 محصولات جدید
(هر محصول: عنوان، شرکت، ۱۵-۲۰ خط خلاصه، اهمیت فنی، اهمیت تجاری، منبع)

📋 پتنت‌های جدید
(هر پتنت: عنوان، متقاضی، تاریخ، ۱۵-۲۰ خط خلاصه، کاربرد صنعتی، منبع)

🔬 مقالات علمی
(هر مقاله: عنوان، نویسندگان، مجله، ۱۵-۲۰ خط خلاصه، یافته‌های کلیدی، منبع)

📰 اخبار بازار و صنعت
(هر خبر: عنوان، سازمان، ۱۵-۲۰ خط خلاصه، تأثیر بر صنعت، منبع)

💡 فرصت‌های نوآوری
(فرصت‌های شناسایی شده با رتبه‌بندی: پتانسیل بالا / متوسط / پایین)

🏆 ۳ ایده محصول ارزشمند هفته
(برای هر ایده: مفهوم، پتانسیل بازار تخمینی، امکان‌پذیری فنی، اقدام پیشنهادی)

─────────────────
🤖 Resin & Adhesive Intelligence Agent
"""

USER_PROMPT = """
Search the web right now for the latest 24 hours only.
Use these exact search queries one by one:

1. "pressure sensitive adhesive" new product 2025 site:adhesivesmag.com OR site:pci-mag.com OR site:coatingsworld.com
2. acrylic emulsion resin patent 2025 site:patents.google.com OR site:wipo.int OR site:epo.org
3. styrene acrylic vinyl acrylic resin news today site:icis.com OR site:chemanalyst.com OR site:specialchem.com
4. Henkel OR "H.B. Fuller" OR Arkema OR Bostik OR Synthomer adhesive announcement 2025
5. BASF OR Dow OR Ashland acrylic resin new product 2025
6. "hot melt adhesive" OR "reactive adhesive" innovation 2025
7. sustainable bio-based adhesive resin 2025 site:mdpi.com OR site:sciencedirect.com OR site:acs.org
8. adhesive resin acquisition merger partnership 2025
9. رزین چسب اکریلیک ایران خاورمیانه ۱۴۰۴
10. acrylic PSA crosslinker monomer emulsifier innovation 2025

After searching, compile all findings and write the full Persian report as instructed.
Today's date: """ + datetime.now(timezone.utc).strftime("%Y-%m-%d") + """

If fewer than 5 real news items are found in the last 24h, expand to last 72 hours and note this clearly.
"""

# ───────────────────────────────────────────────
# ۲. فراخوانی Claude با web search
# ───────────────────────────────────────────────

def generate_report() -> str:
    print("🤖 Calling Claude API with web search...")
    client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

    response = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=8000,
        system=SYSTEM_PROMPT,
        tools=[{"type": "web_search_20250305", "name": "web_search"}],
        messages=[{"role": "user", "content": USER_PROMPT}]
    )

    # جمع‌آوری تمام بلوک‌های متنی
    full_text = ""
    for block in response.content:
        if hasattr(block, "text"):
            full_text += block.text

    if not full_text.strip():
        full_text = "⚠️ گزارش تولید نشد. لطفاً API key و اتصال اینترنت را بررسی کنید."

    print(f"✅ Report generated — {len(full_text.split())} words")
    return full_text


# ───────────────────────────────────────────────
# ۳. ارسال به تلگرام (با تقسیم خودکار)
# ───────────────────────────────────────────────

def send_telegram(text: str):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    max_len = 4000
    parts = [text[i:i+max_len] for i in range(0, len(text), max_len)]

    for i, part in enumerate(parts, 1):
        print(f"📤 Sending part {i}/{len(parts)} to Telegram...")
        payload = {
            "chat_id": CHAT_ID,
            "text": part,
            "parse_mode": "Markdown",
            "disable_web_page_preview": True,
        }
        r = requests.post(url, json=payload, timeout=30)
        data = r.json()
        if not data.get("ok"):
            # اگر Markdown مشکل داشت، بدون parse_mode امتحان کن
            payload.pop("parse_mode")
            r2 = requests.post(url, json=payload, timeout=30)
            if not r2.json().get("ok"):
                raise RuntimeError(f"Telegram error: {r2.json()}")
        print(f"   ✅ Part {i} sent.")


# ───────────────────────────────────────────────
# ۴. اجرای اصلی
# ───────────────────────────────────────────────

def main():
    print("=" * 60)
    print("🧪 Resin & Adhesive Intelligence Agent")
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    report = generate_report()
    send_telegram(report)

    print("=" * 60)
    print("✅ All done! Report sent to Telegram.")
    print("=" * 60)


if __name__ == "__main__":
    main()
